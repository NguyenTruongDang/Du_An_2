$(document).ready(function () {
    $('.show-menu-news').hover(function () {
        $('.show-menu-news .menu-hide-news').css({
            'z-index': '20'
        });
    }, function () {
        $('.show-menu-news .menu-hide-news').css({
            'z-index': '0'
        });
    });
    $('.muiten').hover(function () {
        $(this).find('i').css({ 'transform': 'rotate(180deg)', 'transition': 'all 0.5s ease-in-out' });
    }, function () {
        $(this).find('i').css({ 'transform': 'rotate(0deg)', 'transition': 'all 0.5s ease-in-out' });
    });
    
});